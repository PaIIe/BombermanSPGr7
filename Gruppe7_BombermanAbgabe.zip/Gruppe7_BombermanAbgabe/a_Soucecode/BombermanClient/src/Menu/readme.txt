Menu Code

Textfeld Problem:
Zeile 171-175: Textfeld wird erstellt
Zeile 218: String soll abgerufen werden, aber es kommt nichts raus
