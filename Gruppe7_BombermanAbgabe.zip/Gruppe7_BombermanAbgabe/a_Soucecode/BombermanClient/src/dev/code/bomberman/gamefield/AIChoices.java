package dev.code.bomberman.gamefield;

public enum AIChoices {
	TOP, BOT, LEFT, RIGHT, BOMB
}
