package dev.code.bomberman.gamefield;

public enum GameState {
	MENU, RUNNING, RANKING
}
