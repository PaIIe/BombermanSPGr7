package dev.code.bomberman;

public enum Direction 
{
	NORTH, EAST, SOUTH, WEST
}
