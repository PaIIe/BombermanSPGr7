package dev.code.bomberman;

public enum GameState {
	MENU, RUNNING, RANKING
}
