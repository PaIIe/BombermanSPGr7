/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
package test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import dev.code.bomberman.Bomberman;
import dev.code.bomberman.Bomb;
import dev.code.bomberman.GameObject;
import dev.code.bomberman.Ranking;

/**
 *
 * @author bestx
 */
/*
    public class BombTest {
    private static Bomberman player;
    private static Ranking ranking;
    private static Direction direction;
    private static Boni boni;
    
    
    public BombTest() {
        player.setColumn = 0;
        player.setRow = 0;
        player.ID=55;
        player.armor = true;
        column = 0;
        row = 0;
        ID = 62;
    }
   
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    


    @Test
    public void counterTest()
    {
     bomb.countdownTime = bomb.explosionTime*2/3;
     bomb.setID = 61;
     bomb.counter();
     assertEquals(bomb.getID(),62);
    }
     
     @Test
     public void generateFlamesTest()
     {
         GameField.setPlayer(1,player);
         int Temp = ranking.scorePlayer1;
         GameField.generateFlames();
        
         assertEquals(player.getArmor(),false);
         assertEquals(player.getID(),51);
         assertEquals(ranking.scorePlayer1,Temp-20);
         assertEquals(ranking.isSuicidedPlayer1,true);
     }
     
     @Test
     public void kickedTest()
     {
         bomb.kicked(NORTH);
         assertEquals(bomb.slideNorth(),true);
     }
     

     @Test
     public void destroyWallTest()
     {
         int row = 1;
         int column = 1;
         bomb.destroyWall(row,column);
         assertEquals(GameField.getObject(row,column), boni);
     }
     
*/