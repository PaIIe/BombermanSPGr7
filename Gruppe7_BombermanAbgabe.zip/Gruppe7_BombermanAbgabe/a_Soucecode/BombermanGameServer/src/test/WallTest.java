/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
package test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import dev.code.bomberman.Wall;

/**
 *
 * @author bestx
 */
/*
public class WallTest {
    
    public WallTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        row = 0;
        column = 0;
    }
    

   @Test
   public void dropBoniTest()
   {
   int randomNumber = 0;
   wall.dropBoni(row,column);
   EmptyField empty = new EmptyField(row.column);
   assertEquals(GameField.getObject(row,column),empty);
    }
   
   @Test
   public void setDestroyableTest()
   { 
   wall.setDestroyable(true);
   assertEquals(wall.getDestroyable(),true);
   
    }

   @Test 
   public void getDestroyableTest() 
   {
   wall.getDestroyable(true);
   assertEquals(wall.setDestroyable(),true);
   }

   }
*/