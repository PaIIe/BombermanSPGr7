Bombermanprojekt - Gruppe 7 

		     -- README --
==========================================================

Vorab: Projekt ist nicht komplett funktionsf�hig und es 
gibt zum Teil gro�e Bugs.

----------------------------------------------------------

Es gibt zwei Client-Versionen: 
	-> Client.jar: nur die nackten Clients ohne Men�

	-> Client_Menue.jar: Client, wo unsere Men�-demo
	   eingebunden ist, Verbindung funktioniert nicht.

Start - Variante(1):
- Server.jar starten
- 2mal Client.jar starten

- es ist nur ein Bomberman(gr�n) steuerbar (vielleicht 
  etwas herumprobieren bis es klappt)
- irgendwann h�ngt sich dann der Client f�r den ersten
  Spieler auf (haben keine L�sung gefunden)
- mit 2. Client ist das Spiel aber spielbar
- wenn alle anderen Bomberman get�tet wurde, wird Ranking
  angezeigt (dauert etwas)

ACHTUNG: Server beendet sich nicht; Prozess muss �ber Task-
	 Manager beendet werden!!!!

Start - Variante(2):
- Sever.jar starten
- Client_Menue.jar starten

- ist nur eine Demonstration des Men�s
- wenn der Server l�uft: "Play" -> "Server 1", dann kann
  man seinen Namen eingeben und kommt in die Lobby
- wenn Sever nicht l�uft: "Play" -> "Server 1", dann kommt
  eine Fehlermeldung "disconnected"

ACHTUNG: Server beendet sich nicht; Prozess muss �ber Task-
	 Manager beendet werden!!!!